extern int twice;

void f(void);
extern int  g(void);
