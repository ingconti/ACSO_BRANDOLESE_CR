//
//  struct.h
//  UsingGuards
//
//  Created by ing.conti on 1st March 2021.
//

#ifndef struct_h
#define struct_h

typedef struct {
    int x;
    int y;
} punto;

#endif /* struct_h */
