//
//  LibA.h
//  UsingGuards
//
//  Created by ing.conti on 01/03/21.
//


#include "struct.h"

void DoA(punto P);
