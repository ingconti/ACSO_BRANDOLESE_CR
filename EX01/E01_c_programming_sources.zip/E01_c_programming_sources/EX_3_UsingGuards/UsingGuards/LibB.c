//
//  LibB.c
//  UsingGuards
//
//  Created by ing.conti on 01/03/21.
//

#include "LibB.h"


#include "struct.h"

void DoB(punto P){
    
}
