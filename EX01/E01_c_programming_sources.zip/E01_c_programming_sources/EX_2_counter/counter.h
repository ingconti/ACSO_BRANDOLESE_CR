void incrementa(void);
void decrementa(void);

int stato(void);
