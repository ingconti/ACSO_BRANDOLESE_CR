#include <stdio.h>

int main()
{
#ifdef VERBOSE
    printf("Hello world!\n");
#endif
}
