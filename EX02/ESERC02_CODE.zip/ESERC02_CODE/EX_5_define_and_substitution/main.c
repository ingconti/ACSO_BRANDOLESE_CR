//
//  main.c
//  EX_5_define_and_substitution
//
//  Created by ing.conti on 01/03/21.
//

#define N 3

//#define ALL

int main(int argc, const char * argv[]) {
    int a = 2*N;
#ifdef ALL
    float f = 1.0;
#endif
    return 0;
}
