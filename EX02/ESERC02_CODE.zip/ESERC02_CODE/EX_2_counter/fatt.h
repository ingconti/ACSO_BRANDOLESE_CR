#include "counter.h"

int incfatt( void );
int decfatt( void );
