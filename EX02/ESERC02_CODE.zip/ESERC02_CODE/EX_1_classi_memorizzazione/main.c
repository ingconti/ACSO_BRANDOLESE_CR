#include <stdio.h>
#include "lib.h"

int main(void)
{
    f();
    f();

    printf("%d\n", g());
    printf("%d\n", twice);
}
