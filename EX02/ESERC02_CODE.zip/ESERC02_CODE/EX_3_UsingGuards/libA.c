//
//  LibA.c
//  UsingGuards
//
//  Created by ing.conti on 01/03/21.
//

#include "LibA.h"

#include "struct.h"

void DoA(punto P){
    
}
