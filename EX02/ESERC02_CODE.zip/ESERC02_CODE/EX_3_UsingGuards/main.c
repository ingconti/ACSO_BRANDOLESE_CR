//
//  main.c
//  UsingGuards
//
//  Created by ing.conti on 1st March 2021.
//


#include <stdio.h>
#include "LibA.h"
#include "LibB.h"


int main(int argc, const char * argv[]) {
    punto P;
    DoA(P);
    DoB(P);
    return 0;
}
